./configure \
--prefix=/tools         \
--bindir=/tools/bin     \
--disable-static      \
--libexecdir=/tools/lib \
--libdir=/tools/lib 
make
