export PATH=$PATH:/usr/share/apache-ant/bin
export ANT_HOME=${ANT_HOME:-/usr/share/apache-ant}
