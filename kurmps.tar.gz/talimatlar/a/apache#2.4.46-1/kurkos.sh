mkdir -p /srv/www
[ ! -d /run/httpd ] && install -dm755 /run/httpd 
