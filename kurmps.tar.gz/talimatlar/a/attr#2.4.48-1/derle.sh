./configure --prefix=/tools \
--bindir=/tools/bin     \
--disable-static  \
--disable-doc  \
--sysconfdir=/tools/etc \
--libdir=/tools/lib \
--libexecdir=/tools/lib \

make
