export HIVE_HOME="/usr/mdp/hive"
export HIVE_CONF_DIR=$HIVE_HOME/conf
