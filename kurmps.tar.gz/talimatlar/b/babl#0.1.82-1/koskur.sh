mkdir -p /usr/share/gir-1.0/
mkdir -p /usr/lib/girepository-1.0
