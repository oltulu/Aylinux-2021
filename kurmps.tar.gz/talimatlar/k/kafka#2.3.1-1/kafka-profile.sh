export KAFKA_HOME="/usr/mdp/kafka"
