./configure $confopt \
--enable-color \
--enable-nanorc \
--enable-multibuffer \
--disable-wrapping-as-root

make
