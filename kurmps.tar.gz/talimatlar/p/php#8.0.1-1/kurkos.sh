mkdir -p /run/php-fpm
mkdir -p /srv/www
