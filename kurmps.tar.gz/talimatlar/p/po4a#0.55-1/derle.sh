  perl Build.PL installdirs=vendor create_packlist=0
  # Betik UTF-8 yerel ayarını bekliyor
  LC_ALL=en_US.UTF-8 perl Build