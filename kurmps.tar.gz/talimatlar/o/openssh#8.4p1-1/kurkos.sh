[ ! -d /var/empty ] && install -dm755 /var/empty
