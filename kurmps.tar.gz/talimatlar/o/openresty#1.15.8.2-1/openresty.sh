#!/bin/sh
[ -d /opt/openresty/bin ] && PATH=$PATH:/opt/openresty/bin
[ -d /opt/openresty/nginx/sbin ] && PATH=$PATH:/opt/openresty/nginx/sbin
export PATH
