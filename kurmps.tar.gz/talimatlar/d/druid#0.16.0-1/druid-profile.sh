export DRUID_HOME="/usr/mdp/druid"
