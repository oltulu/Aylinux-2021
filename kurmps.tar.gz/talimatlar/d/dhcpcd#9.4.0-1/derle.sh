./configure \
--prefix=/usr \
--sysconfdir=/etc \
--sbindir=/usr/bin \
--libexecdir=/usr/lib/dhcpcd \
--dbdir=/var/lib/dhcpcd \
--rundir=/run

make
