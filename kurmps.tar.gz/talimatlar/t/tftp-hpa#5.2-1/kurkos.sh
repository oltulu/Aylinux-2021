install -d --group=nogroup --owner=nobody /var/lib/tftpboot
