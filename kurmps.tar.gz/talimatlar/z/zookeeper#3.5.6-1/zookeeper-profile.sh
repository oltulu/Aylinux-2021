export ZOOKEEPER_HOME="/usr/mdp/zookeeper"
