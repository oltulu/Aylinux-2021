export MAVEN_OPTS=-Xmx512m
export M2_HOME=/usr/share/maven
export PATH=$PATH:$M2_HOME/bin
