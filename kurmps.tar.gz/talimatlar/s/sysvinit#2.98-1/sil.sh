rm -f $PKG/usr/bin/last
rm -f $PKG/usr/bin/lastb
rm -f $PKG/sbin/logsave
rm -f $PKG/usr/bin/mesg
rm -f $PKG/bin/pidof
rm -f $PKG/sbin/sulogin
rm -f $PKG/usr/bin/utmpdump
rm -f $PKG/usr/bin/wall
