. /lib/lsb/init-functions
sed -i "s/^id:[3-5]/id:5/" /etc/inittab
echo  "Init default set to 5 in the /etc/inittab file"
