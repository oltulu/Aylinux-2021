update-ca-certificates --fresh >/dev/null 2>&1
