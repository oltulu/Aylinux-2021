chgrp -R lp /etc/cups
