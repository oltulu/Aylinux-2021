# glib için schema içeren paketlerin otomatik şema derleme işlemidir.
kur=1

kontrol="grep lsb/init-functions etc/rc.d/init.d/*"
betik="service fixer"
