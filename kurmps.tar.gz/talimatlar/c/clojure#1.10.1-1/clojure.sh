export CLOJURE_HOME=/usr/share/clojure
