/usr/lib/vlc/vlc-cache-gen /usr/lib/vlc/plugins
