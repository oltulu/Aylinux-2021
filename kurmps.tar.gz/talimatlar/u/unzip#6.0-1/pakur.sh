cd "${SRC}/${isim}60"
make -f unix/Makefile prefix="${PKG}"/usr install
