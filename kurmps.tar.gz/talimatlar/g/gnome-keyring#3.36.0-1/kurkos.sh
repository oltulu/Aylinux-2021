setcap cap_ipc_lock=ep /usr/bin/gnome-keyring-daemon
