#!/bin/sh
[ -d /var/lib/mps/db/ghc-bin ]  && mps sil ghc-bin --ona
