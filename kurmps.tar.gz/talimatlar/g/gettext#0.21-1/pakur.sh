cd gettext-tools	
mkdir -p $PKG/tools/bin
cp -v src/{msgfmt,msgmerge,xgettext} $PKG/tools/bin
