rm -f /usr/lib/gtk-3.0/3.0.0/immodules.cache
