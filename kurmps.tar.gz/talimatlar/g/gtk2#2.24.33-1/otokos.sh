# glib için schema içeren paketlerin otomatik şema derleme işlemidir.
kur=1
sil=1

kontrol="ls usr/lib/gtk-2.0/2.10.0/immodules/*.so"
betik="/usr/bin/gtk-query-immodules-2.0 --update-cache"
