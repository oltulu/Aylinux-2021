#!/bin/sh
#
# /usr/bin/gtk-register: register gdk-pixbuf loaders
#

gdk-pixbuf-query-loaders --update-cache

# End of file
