# Gdk-pixbuf modülü içeren paketlerin otomatik önbellek güncelleme işlemidir.
kur=1
sil=1

kontrol="ls usr/lib/gdk-pixbuf-2.0/2.10.0/loaders/*.so"
betik="gdk-pixbuf-query-loaders --update-cache"
