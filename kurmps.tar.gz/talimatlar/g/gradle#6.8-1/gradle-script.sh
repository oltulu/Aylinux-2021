#!/bin/sh
APP_NAME="Gradle"
APP_BASE_NAME=`basename "$0"`
APP_HOME="/usr/lib/gradle"
APP_VERSION=@VERSION@

java $JAVA_OPTS -classpath $APP_HOME/lib/gradle-launcher-$APP_VERSION.jar org.gradle.launcher.GradleMain "$@"
