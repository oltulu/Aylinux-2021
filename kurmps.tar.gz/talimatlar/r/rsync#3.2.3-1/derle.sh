./configure $confopt \
--with-included-popt=no \
--with-included-zlib=yes \
--disable-debug
make 
