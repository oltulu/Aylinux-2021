depmod
echo "modprobe wireless_code(rtl8723de) komutu verin."
