#!/bin/sh
exec /opt/firefox/firefox --class "Firefox" --name "Firefox" "$@"