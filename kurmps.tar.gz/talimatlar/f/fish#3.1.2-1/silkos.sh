sed -ri -e '\|^/usr/bin/fish$|d' -e '\|^/bin/fish$|d' /etc/shells
