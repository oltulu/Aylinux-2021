gtk-update-icon-cache /usr/share/icons/elementary-xfce
[ -d  ~/.icons ] && gtk-update-icon-cache ~/.icons/elementary-xfce-dark
gtk-update-icon-cache /usr/share/icons/elementary-xfce-dark
[ -d  ~/.icons ] && gtk-update-icon-cache ~/.icons/elementary-xfce-dark
gtk-update-icon-cache /usr/share/icons/elementary-xfce-darker
[ -d  ~/.icons ] && gtk-update-icon-cache ~/.icons/elementary-xfce-dark
