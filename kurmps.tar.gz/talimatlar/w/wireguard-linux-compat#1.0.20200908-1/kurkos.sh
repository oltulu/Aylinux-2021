depmod
modprobe wireguard
