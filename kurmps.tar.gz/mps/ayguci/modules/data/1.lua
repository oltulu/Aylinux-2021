-- string veri
local ret={}
ret.data="veri1"
result=json.encode(ret)
