-- table verisi
dtable={ali="kddd",veli="dff444df"}
result=json.encode(dtable)
--print(data)
