## Ayguci

Milis Linux Sistemi Bilgi ve Ayar Uygulaması


```
# Aşağıdaki komutları yetkili olarak uygulayın.
# Kurulum.
./setup.sh

# Ayguci servisi aktif edin.
service start ayguci

# Ayguci terminal arayüz başlatma.
ayguci tui

# Ayguci grafiksel arayüz başlatma.
ayguci gui
```
