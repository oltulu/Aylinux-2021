luastatic tui.lua form.lua json.lua serpent.lua /usr/lib/liblua.a newt.so -o tui
